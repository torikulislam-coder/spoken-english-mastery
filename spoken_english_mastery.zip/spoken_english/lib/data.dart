import 'dart:convert';
import 'package:flutter/services.dart';

class Phrase {
  final String id;
  final String en;
  final Map<String, String> tr; // bn, hi, ur, ar
  const Phrase(this.id, this.en, this.tr);
  String native(String lang) => lang == 'en' ? '' : (tr[lang] ?? '');
}

class Lesson {
  final String id;
  final int level;
  final int index; // global order
  final Map<String, String> title;
  final List<Phrase> phrases;
  const Lesson(this.id, this.level, this.index, this.title, this.phrases);
  String name(String lang) => title[lang] ?? title['en'] ?? id;
}

class Level {
  final int id;
  final Map<String, String> title;
  final Map<String, String> topics;
  final List<Lesson> lessons;
  const Level(this.id, this.title, this.topics, this.lessons);
  String name(String lang) => title[lang] ?? title['en'] ?? '';
  String topic(String lang) => topics[lang] ?? topics['en'] ?? '';
}

class Content {
  final List<Level> levels;
  final List<Lesson> lessons;
  final Map<String, Phrase> phraseById;
  Content(this.levels, this.lessons, this.phraseById);

  static Future<Content> load() async {
    final raw = await rootBundle.loadString('assets/content/levels.json');
    final j = jsonDecode(raw) as Map<String, dynamic>;
    final levels = <Level>[];
    final all = <Lesson>[];
    final byId = <String, Phrase>{};
    for (final lv in (j['levels'] as List)) {
      final lessons = <Lesson>[];
      for (final l in (lv['lessons'] as List)) {
        final phrases = <Phrase>[];
        var n = 0;
        for (final p in (l['phrases'] as List)) {
          n++;
          final m = Map<String, dynamic>.from(p as Map);
          final id = '${l['id']}-$n';
          final ph = Phrase(id, m['en'] as String, {
            for (final k in ['bn', 'hi', 'ur', 'ar']) k: (m[k] ?? '') as String,
          });
          phrases.add(ph);
          byId[id] = ph;
        }
        final lesson = Lesson(
          l['id'] as String,
          lv['id'] as int,
          all.length,
          Map<String, String>.from(l['title'] as Map),
          phrases,
        );
        lessons.add(lesson);
        all.add(lesson);
      }
      levels.add(Level(
        lv['id'] as int,
        Map<String, String>.from(lv['title'] as Map),
        Map<String, String>.from(lv['topics'] as Map),
        lessons,
      ));
    }
    return Content(levels, all, byId);
  }
}

/// Pronunciation groups (language-independent English examples, tips in 5 languages: en, bn, hi, ur, ar).
class SoundGroup {
  final String title;
  final List<String> words;
  final List<String> tips;
  const SoundGroup(this.title, this.words, this.tips);
}

const kSoundGroups = [
  SoundGroup('th sounds', ['think', 'this', 'three', 'mother', 'thank', 'they'], [
    'Put the tip of your tongue lightly between your teeth and let the air flow. It is not "t" or "d".',
    'জিভের ডগা হালকাভাবে দাঁতের মাঝে রেখে বাতাস ছাড়ুন। এটা "ত" বা "দ" নয়।',
    'जीभ की नोक को हल्के से दाँतों के बीच रखकर हवा छोड़ें। यह "त" या "द" नहीं है।',
    'زبان کی نوک کو ہلکے سے دانتوں کے درمیان رکھ کر ہوا نکالیں۔ یہ "ت" یا "د" نہیں ہے۔',
    'ضع طرف لسانك برفق بين أسنانك ودع الهواء يمر. ليس "ت" أو "د".',
  ]),
  SoundGroup('v and w', ['very', 'wary', 'vine', 'wine', 'vest', 'west'], [
    'For "v", lightly touch your top teeth to your lower lip. For "w", round your lips and do not touch your teeth.',
    '"v"-এর জন্য ওপরের দাঁত নিচের ঠোঁটে হালকা ছোঁয়ান। "w"-এর জন্য ঠোঁট গোল করুন, দাঁত ছোঁয়াবেন না।',
    '"v" के लिए ऊपर के दाँत निचले होंठ से हल्के छुएँ। "w" के लिए होंठ गोल करें, दाँत न छुएँ।',
    '"v" کے لیے اوپر کے دانت نچلے ہونٹ سے ہلکے چھوئیں۔ "w" کے لیے ہونٹ گول کریں، دانت نہ چھوئیں۔',
    'للحرف "v" المس شفتك السفلى بأسنانك العليا برفق. للحرف "w" دوّر شفتيك دون لمس الأسنان.',
  ]),
  SoundGroup('Short and long vowels', ['ship', 'sheep', 'full', 'fool', 'bit', 'beat'], [
    'Long vowels last longer: "sheep" is held, "ship" is quick.',
    'দীর্ঘ স্বর বেশি সময় ধরে থাকে: "sheep" টানা, "ship" ছোট।',
    'लंबे स्वर ज़्यादा देर तक रहते हैं: "sheep" लंबा, "ship" छोटा।',
    'لمبی آوازیں زیادہ دیر تک رہتی ہیں: "sheep" لمبا، "ship" چھوٹا۔',
    'الحروف الطويلة تُمدّ أكثر: "sheep" ممدودة و"ship" قصيرة.',
  ]),
  SoundGroup('Word endings', ['worked', 'played', 'books', 'bags', 'asked', 'helped'], [
    'Say the final sound clearly. "Worked" ends with a "t" sound, "played" with a "d" sound.',
    'শেষ ধ্বনিটি স্পষ্ট বলুন। "worked" শেষ হয় "t" ধ্বনিতে, "played" শেষ হয় "d" ধ্বনিতে।',
    'आख़िरी ध्वनि साफ़ बोलें। "worked" का अंत "t" ध्वनि से और "played" का "d" ध्वनि से होता है।',
    'آخری آواز صاف بولیں۔ "worked" کا اختتام "t" پر اور "played" کا "d" پر ہوتا ہے۔',
    'انطق الصوت الأخير بوضوح. "worked" تنتهي بصوت "t" و"played" بصوت "d".',
  ]),
  SoundGroup('Consonant clusters', ['school', 'street', 'spring', 'speak', 'station', 'small'], [
    'Do not add a vowel before "s" clusters. Say "school", not "eschool".',
    '"s" দিয়ে শুরু ক্লাস্টারের আগে স্বর যোগ করবেন না। "school" বলুন, "iskul" নয়।',
    '"s" वाले संयुक्त व्यंजनों से पहले स्वर न जोड़ें। "school" बोलें, "iskool" नहीं।',
    '"s" والے مرکب حروف سے پہلے حرکت نہ لگائیں۔ "school" بولیں، "iskool" نہیں۔',
    'لا تضف حرف علة قبل مجموعات "s". قل "school" وليس "eschool".',
  ]),
  SoundGroup('R and L', ['right', 'light', 'red', 'led', 'rice', 'lice'], [
    'For "r", curl your tongue back without touching anything. For "l", touch the tip of your tongue behind your top teeth.',
    '"r"-এর জন্য জিভ পেছনে গুটিয়ে কিছু না ছুঁয়ে রাখুন। "l"-এর জন্য জিভের ডগা ওপরের দাঁতের পেছনে ছোঁয়ান।',
    '"r" के लिए जीभ को पीछे मोड़ें, कुछ न छुएँ। "l" के लिए जीभ की नोक ऊपर के दाँतों के पीछे लगाएँ।',
    '"r" کے لیے زبان پیچھے موڑیں، کچھ نہ چھوئیں۔ "l" کے لیے زبان کی نوک اوپر کے دانتوں کے پیچھے لگائیں۔',
    'للحرف "r" اثنِ لسانك للخلف دون أن يلمس شيئاً. للحرف "l" المس بطرف لسانك خلف الأسنان العليا.',
  ]),
];

String soundTip(SoundGroup g, String lang) {
  const order = ['en', 'bn', 'hi', 'ur', 'ar'];
  final i = order.indexOf(lang);
  return g.tips[i < 0 ? 0 : i];
}
