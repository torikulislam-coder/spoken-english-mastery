import 'package:flutter/foundation.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:speech_to_text/speech_recognition_result.dart';
import 'package:speech_to_text/speech_to_text.dart';

class WordResult {
  final String word;
  final bool ok;
  const WordResult(this.word, this.ok);
}

class Score {
  final double pct;
  final List<WordResult> words;
  const Score(this.pct, this.words);
}

const _contractions = {
  "i'm": 'i am', "you're": 'you are', "it's": 'it is', "that's": 'that is', "what's": 'what is',
  "where's": 'where is', "he's": 'he is', "she's": 'she is', "we're": 'we are', "they're": 'they are',
  "don't": 'do not', "doesn't": 'does not', "can't": 'cannot', "i'll": 'i will', "let's": 'let us',
  "i'd": 'i would', "won't": 'will not', "isn't": 'is not', "aren't": 'are not',
};

const _numbers = {
  '0': 'zero', '1': 'one', '2': 'two', '3': 'three', '4': 'four', '5': 'five', '6': 'six', '7': 'seven',
  '8': 'eight', '9': 'nine', '10': 'ten', '11': 'eleven', '12': 'twelve', '20': 'twenty', '30': 'thirty',
  '50': 'fifty', '100': 'one hundred',
};

List<String> _tok(String s) {
  var t = s.toLowerCase().replaceAll('\u2019', "'");
  _contractions.forEach((k, v) => t = t.replaceAll(k, v));
  t = t.replaceAll(RegExp(r'[^a-z0-9 ]'), ' ');
  final out = <String>[];
  for (final w in t.split(RegExp(r'\s+'))) {
    if (w.isEmpty) continue;
    final n = _numbers[w];
    if (n != null) {
      out.addAll(n.split(' '));
    } else {
      out.add(w);
    }
  }
  return out;
}

int _lev(String a, String b) {
  if (a == b) return 0;
  if (a.isEmpty) return b.length;
  if (b.isEmpty) return a.length;
  var prev = List<int>.generate(b.length + 1, (i) => i);
  for (var i = 1; i <= a.length; i++) {
    final cur = List<int>.filled(b.length + 1, 0);
    cur[0] = i;
    for (var j = 1; j <= b.length; j++) {
      final cost = a[i - 1] == b[j - 1] ? 0 : 1;
      var best = prev[j] + 1;
      if (cur[j - 1] + 1 < best) best = cur[j - 1] + 1;
      if (prev[j - 1] + cost < best) best = prev[j - 1] + cost;
      cur[j] = best;
    }
    prev = cur;
  }
  return prev[b.length];
}

/// Word-level match between the target sentence and what the recogniser heard.
Score scoreSpeech(String target, String heard) {
  final t = _tok(target);
  final h = _tok(heard);
  final used = List<bool>.filled(h.length, false);
  final res = <WordResult>[];
  var ok = 0;
  for (final w in t) {
    var found = false;
    for (var i = 0; i < h.length; i++) {
      if (used[i]) continue;
      final tol = w.length >= 6 ? 1 : 0;
      if (_lev(w, h[i]) <= tol) {
        used[i] = true;
        found = true;
        break;
      }
    }
    if (found) ok++;
    res.add(WordResult(w, found));
  }
  return Score(t.isEmpty ? 0 : ok / t.length, res);
}

class SpeechService extends ChangeNotifier {
  final FlutterTts _tts = FlutterTts();
  final SpeechToText _stt = SpeechToText();
  bool sttReady = false;
  bool ttsReady = false;
  bool listening = false;
  bool speaking = false;
  String heard = '';
  void Function(String)? _cb;

  Future<void> init() async {
    try {
      await _tts.setLanguage('en-US');
      await _tts.setSpeechRate(0.45);
      await _tts.setPitch(1.0);
      await _tts.awaitSpeakCompletion(true);
      ttsReady = true;
    } catch (_) {
      ttsReady = false;
    }
    await _initStt();
  }

  Future<void> _initStt() async {
    try {
      sttReady = await _stt.initialize(
        onStatus: _onStatus,
        onError: (e) {
          listening = false;
          final cb = _cb;
          _cb = null;
          notifyListeners();
          cb?.call('');
        },
      );
    } catch (_) {
      sttReady = false;
    }
    notifyListeners();
  }

  Future<void> retry() => _initStt();

  void _onStatus(String s) {
    final was = listening;
    listening = s == 'listening';
    notifyListeners();
    if (was && !listening) {
      Future.delayed(const Duration(milliseconds: 350), () {
        final cb = _cb;
        if (cb != null) {
          _cb = null;
          cb(heard);
        }
      });
    }
  }

  Future<void> speak(String text, {bool slow = false}) async {
    if (!ttsReady) return;
    try {
      await _tts.stop();
      await _tts.setSpeechRate(slow ? 0.28 : 0.45);
      speaking = true;
      notifyListeners();
      await _tts.speak(text);
    } catch (_) {}
    speaking = false;
    notifyListeners();
  }

  Future<void> stopSpeaking() async {
    try {
      await _tts.stop();
    } catch (_) {}
    speaking = false;
    notifyListeners();
  }

  Future<bool> startListening(void Function(String) onFinal) async {
    if (!sttReady) await _initStt();
    if (!sttReady) return false;
    await stopSpeaking();
    heard = '';
    _cb = onFinal;
    listening = true;
    notifyListeners();
    try {
      await _stt.listen(
        onResult: (SpeechRecognitionResult r) {
          heard = r.recognizedWords;
          notifyListeners();
          if (r.finalResult) {
            final cb = _cb;
            _cb = null;
            cb?.call(heard);
          }
        },
        localeId: 'en_US',
        listenFor: const Duration(seconds: 20),
        pauseFor: const Duration(seconds: 3),
      );
    } catch (_) {
      listening = false;
      _cb = null;
      notifyListeners();
      return false;
    }
    return true;
  }

  Future<void> stopListening() async {
    try {
      await _stt.stop();
    } catch (_) {}
  }
}
