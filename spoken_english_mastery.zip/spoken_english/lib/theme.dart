import 'package:flutter/material.dart';

const kBrand = Color(0xFF12945F);
const kBrandDark = Color(0xFF0A5C3E);
const kMint = Color(0xFFE8F7EF);
const kGold = Color(0xFFFFC53D);
const kInk = Color(0xFF10201A);
const kMuted = Color(0xFF66766E);
const kBg = Color(0xFFF4FAF7);
const kLine = Color(0xFFDDEAE3);
const kRed = Color(0xFFE5484D);
const kBlue = Color(0xFF3B82F6);

const kFontFallback = ['HindSiliguri'];

ThemeData buildTheme() {
  final scheme = ColorScheme.fromSeed(seedColor: kBrand, brightness: Brightness.light)
      .copyWith(primary: kBrand, onPrimary: Colors.white, surface: Colors.white);
  OutlineInputBorder ob(Color c, [double w = 1]) =>
      OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide(color: c, width: w));
  return ThemeData(
    useMaterial3: true,
    // Latin text and numbers use Poppins; Bangla (and other scripts) fall back to Hind Siliguri / system fonts.
    fontFamily: 'Poppins',
    fontFamilyFallback: kFontFallback,
    colorScheme: scheme,
    scaffoldBackgroundColor: kBg,
    appBarTheme: const AppBarTheme(
      backgroundColor: kBg,
      foregroundColor: kInk,
      elevation: 0,
      scrolledUnderElevation: 0,
      centerTitle: false,
      titleTextStyle: TextStyle(
        color: kInk, fontSize: 20, fontWeight: FontWeight.w700, fontFamily: 'Poppins', fontFamilyFallback: kFontFallback,
      ),
    ),
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: Colors.white,
      border: ob(kLine),
      enabledBorder: ob(kLine),
      focusedBorder: ob(kBrand, 1.6),
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 15),
    ),
    filledButtonTheme: FilledButtonThemeData(
      style: FilledButton.styleFrom(
        backgroundColor: kBrand,
        foregroundColor: Colors.white,
        minimumSize: const Size(64, 54),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
        textStyle: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
      ),
    ),
    outlinedButtonTheme: OutlinedButtonThemeData(
      style: OutlinedButton.styleFrom(
        foregroundColor: kInk,
        minimumSize: const Size(64, 50),
        side: const BorderSide(color: kLine, width: 1.4),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
        textStyle: const TextStyle(fontSize: 15, fontWeight: FontWeight.w600),
      ),
    ),
    dividerColor: kLine,
  );
}
