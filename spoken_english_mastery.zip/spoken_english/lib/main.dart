import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'screens/onboarding.dart';
import 'screens/shell.dart';
import 'speech.dart';
import 'store.dart';
import 'theme.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(
    MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => AppState()..init()),
        ChangeNotifierProvider(create: (_) => SpeechService()..init()),
      ],
      child: const SpokenEnglishApp(),
    ),
  );
}

class SpokenEnglishApp extends StatelessWidget {
  const SpokenEnglishApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Spoken English Mastery',
      debugShowCheckedModeBanner: false,
      theme: buildTheme(),
      home: const Gate(),
    );
  }
}

class Gate extends StatelessWidget {
  const Gate({super.key});
  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppState>();
    if (!s.ready) {
      return const Scaffold(
        backgroundColor: kBrand,
        body: Center(child: Icon(Icons.record_voice_over_rounded, color: Colors.white, size: 72)),
      );
    }
    return s.onboarded ? const Shell() : const OnboardingScreen();
  }
}
