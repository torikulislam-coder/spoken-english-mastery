import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'l10n.dart';
import 'speech.dart';
import 'store.dart';
import 'theme.dart';

Future<T?> push<T>(BuildContext c, Widget w) => Navigator.of(c).push<T>(MaterialPageRoute(builder: (_) => w));

void toast(BuildContext c, String msg) {
  ScaffoldMessenger.of(c).hideCurrentSnackBar();
  ScaffoldMessenger.of(c).showSnackBar(SnackBar(content: Text(msg), behavior: SnackBarBehavior.floating));
}

Future<bool> confirmDialog(BuildContext c, String title, {String? yes, String? no}) async {
  final s = c.read<AppState>();
  final r = await showDialog<bool>(
    context: c,
    builder: (ctx) => AlertDialog(
      title: Text(title),
      actions: [
        TextButton(onPressed: () => Navigator.pop(ctx, false), child: Text(no ?? s.t('cancel'))),
        TextButton(onPressed: () => Navigator.pop(ctx, true), child: Text(yes ?? s.t('yes'))),
      ],
    ),
  );
  return r ?? false;
}

class Panel extends StatelessWidget {
  const Panel({
    super.key,
    required this.child,
    this.padding = const EdgeInsets.all(18),
    this.margin = EdgeInsets.zero,
    this.color,
    this.onTap,
    this.borderColor,
    this.radius = 22,
  });
  final Widget child;
  final EdgeInsets padding;
  final EdgeInsets margin;
  final Color? color;
  final VoidCallback? onTap;
  final Color? borderColor;
  final double radius;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: margin,
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(radius),
          boxShadow: [BoxShadow(color: kBrandDark.withAlpha(16), blurRadius: 18, offset: const Offset(0, 6))],
        ),
        child: Material(
          color: color ?? Colors.white,
          clipBehavior: Clip.antiAlias,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(radius),
            side: BorderSide(color: borderColor ?? kLine),
          ),
          child: InkWell(onTap: onTap, child: Padding(padding: padding, child: child)),
        ),
      ),
    );
  }
}

class NativeText extends StatelessWidget {
  const NativeText(this.text, this.lang, {super.key, this.style, this.align = TextAlign.center});
  final String text;
  final String lang;
  final TextStyle? style;
  final TextAlign align;
  @override
  Widget build(BuildContext context) => Directionality(
        textDirection: langOf(lang).rtl ? TextDirection.rtl : TextDirection.ltr,
        child: Text(text, textAlign: align, style: style),
      );
}

class StatChip extends StatelessWidget {
  const StatChip(this.icon, this.text, {super.key, this.color = kGold, this.dark = true});
  final IconData icon;
  final String text;
  final Color color;
  final bool dark;
  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
        decoration: BoxDecoration(
          color: dark ? Colors.white.withAlpha(34) : kMint,
          borderRadius: BorderRadius.circular(30),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(icon, color: color, size: 18),
            const SizedBox(width: 6),
            Text(text, style: TextStyle(color: dark ? Colors.white : kInk, fontWeight: FontWeight.w600, fontSize: 13.5)),
          ],
        ),
      );
}

class RoundIcon extends StatelessWidget {
  const RoundIcon({super.key, required this.icon, required this.onTap, this.label, this.filled = false, this.size = 54});
  final IconData icon;
  final VoidCallback onTap;
  final String? label;
  final bool filled;
  final double size;
  @override
  Widget build(BuildContext context) => Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Material(
            color: filled ? kBrand : kMint,
            shape: const CircleBorder(),
            child: InkWell(
              customBorder: const CircleBorder(),
              onTap: onTap,
              child: SizedBox(width: size, height: size, child: Icon(icon, color: filled ? Colors.white : kBrandDark, size: size * 0.48)),
            ),
          ),
          if (label != null) ...[
            const SizedBox(height: 6),
            Text(label!, style: const TextStyle(fontSize: 12, color: kMuted, fontWeight: FontWeight.w500)),
          ],
        ],
      );
}

class MicButton extends StatefulWidget {
  const MicButton({super.key, required this.active, required this.onTap, this.size = 76, this.ring = true});
  final bool active;
  final VoidCallback onTap;
  final double size;
  final bool ring;
  @override
  State<MicButton> createState() => _MicButtonState();
}

class _MicButtonState extends State<MicButton> with SingleTickerProviderStateMixin {
  late final AnimationController _c = AnimationController(vsync: this, duration: const Duration(milliseconds: 1300));

  @override
  void initState() {
    super.initState();
    if (widget.active) _c.repeat();
  }

  @override
  void didUpdateWidget(covariant MicButton old) {
    super.didUpdateWidget(old);
    if (widget.active && !_c.isAnimating) {
      _c.repeat();
    } else if (!widget.active && _c.isAnimating) {
      _c.stop();
      _c.value = 0;
    }
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final extra = widget.ring ? 46.0 : 0.0;
    return SizedBox(
      width: widget.size + extra,
      height: widget.size + extra,
      child: AnimatedBuilder(
        animation: _c,
        builder: (context, _) {
          final t = _c.value;
          return Stack(
            alignment: Alignment.center,
            children: [
              if (widget.active && widget.ring)
                Container(
                  width: widget.size + extra * t,
                  height: widget.size + extra * t,
                  decoration: BoxDecoration(shape: BoxShape.circle, color: kRed.withAlpha((90 * (1 - t)).round())),
                ),
              Material(
                color: widget.active ? kRed : kBrand,
                shape: const CircleBorder(),
                elevation: 4,
                child: InkWell(
                  customBorder: const CircleBorder(),
                  onTap: widget.onTap,
                  child: SizedBox(
                    width: widget.size,
                    height: widget.size,
                    child: Icon(widget.active ? Icons.stop_rounded : Icons.mic, color: Colors.white, size: widget.size * 0.46),
                  ),
                ),
              ),
            ],
          );
        },
      ),
    );
  }
}

/// Mic + word-level feedback for a target sentence.
class SpeakPractice extends StatefulWidget {
  const SpeakPractice({super.key, required this.target, required this.onScore, this.compact = false});
  final String target;
  final void Function(double pct) onScore; // -1 means "not scored" (no speech recognition)
  final bool compact;
  @override
  State<SpeakPractice> createState() => _SpeakPracticeState();
}

class _SpeakPracticeState extends State<SpeakPractice> {
  Score? score;
  String heard = '';
  bool noSpeech = false;

  Future<void> _toggle() async {
    final sp = context.read<SpeechService>();
    if (sp.listening) {
      await sp.stopListening();
      return;
    }
    setState(() {
      score = null;
      heard = '';
      noSpeech = false;
    });
    final ok = await sp.startListening((h) {
      if (!mounted) return;
      if (h.trim().isEmpty) {
        setState(() => noSpeech = true);
        widget.onScore(0);
        return;
      }
      final sc = scoreSpeech(widget.target, h);
      setState(() {
        heard = h;
        score = sc;
      });
      widget.onScore(sc.pct);
    });
    if (!ok && mounted) setState(() => noSpeech = true);
  }

  Widget _chips() {
    final sc = score!;
    return Wrap(
      alignment: WrapAlignment.center,
      spacing: 6,
      runSpacing: 6,
      children: [
        for (final w in sc.words)
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
            decoration: BoxDecoration(
              color: (w.ok ? kBrand : kRed).withAlpha(26),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Text(w.word, style: TextStyle(color: w.ok ? kBrandDark : kRed, fontWeight: FontWeight.w600)),
          ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppState>();
    final sp = context.watch<SpeechService>();

    if (!sp.sttReady && !sp.listening) {
      return Column(
        children: [
          Text(s.t('no_mic'), textAlign: TextAlign.center, style: const TextStyle(color: kMuted, fontSize: 13, height: 1.4)),
          const SizedBox(height: 10),
          OutlinedButton(onPressed: () => widget.onScore(-1), child: Text(s.t('i_said_it'))),
        ],
      );
    }

    if (widget.compact) {
      return Row(
        children: [
          MicButton(active: sp.listening, onTap: _toggle, size: 42, ring: false),
          const SizedBox(width: 10),
          Expanded(
            child: sp.listening
                ? Text(sp.heard.isEmpty ? s.t('listening') : sp.heard, style: const TextStyle(color: kMuted))
                : (score == null
                    ? const SizedBox()
                    : Row(
                        children: [
                          Icon(score!.pct >= 0.7 ? Icons.check_circle : Icons.cancel, color: score!.pct >= 0.7 ? kBrand : kRed, size: 20),
                          const SizedBox(width: 6),
                          Expanded(child: Text(heard, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: kMuted))),
                        ],
                      )),
          ),
        ],
      );
    }

    return Column(
      children: [
        MicButton(active: sp.listening, onTap: _toggle),
        const SizedBox(height: 4),
        Text(sp.listening ? s.t('listening') : s.t('tap_speak'), style: const TextStyle(color: kMuted, fontWeight: FontWeight.w500)),
        const SizedBox(height: 12),
        if (sp.listening && sp.heard.isNotEmpty)
          Text('"${sp.heard}"', textAlign: TextAlign.center, style: const TextStyle(fontSize: 16, color: kInk)),
        if (!sp.listening && noSpeech) Text(s.t('try_again'), style: const TextStyle(color: kRed, fontWeight: FontWeight.w600)),
        if (!sp.listening && score != null) ...[
          Text(s.t('you_said'), style: const TextStyle(color: kMuted, fontSize: 12.5)),
          const SizedBox(height: 4),
          Text('"$heard"', textAlign: TextAlign.center, style: const TextStyle(fontSize: 15.5)),
          const SizedBox(height: 10),
          _chips(),
          const SizedBox(height: 10),
          Text('${(score!.pct * 100).round()}%',
              style: TextStyle(fontSize: 22, fontWeight: FontWeight.w700, color: score!.pct >= 0.7 ? kBrand : kRed)),
        ],
      ],
    );
  }
}
