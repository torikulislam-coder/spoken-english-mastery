import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import 'package:url_launcher/url_launcher.dart';
import '../l10n.dart';
import '../store.dart';
import '../theme.dart';
import '../widgets.dart';
import 'ai_chat.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  Widget _sectionTitle(String t) => Padding(
        padding: const EdgeInsets.only(top: 22, bottom: 10),
        child: Text(t, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
      );

  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppState>();
    final initial = s.name.isEmpty ? 'S' : String.fromCharCode(s.name.runes.first).toUpperCase();
    return Scaffold(
      appBar: AppBar(title: Text(s.t('nav_profile'))),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(18, 4, 18, 30),
        children: [
          Panel(
            onTap: () async {
              final c = TextEditingController(text: s.name);
              final r = await showDialog<String>(
                context: context,
                builder: (ctx) => AlertDialog(
                  title: Text(s.t('your_name')),
                  content: TextField(controller: c, autofocus: true, textCapitalization: TextCapitalization.words),
                  actions: [
                    TextButton(onPressed: () => Navigator.pop(ctx), child: Text(s.t('cancel'))),
                    TextButton(onPressed: () => Navigator.pop(ctx, c.text), child: Text(s.t('save'))),
                  ],
                ),
              );
              if (r != null) await s.setName(r);
            },
            child: Row(
              children: [
                CircleAvatar(radius: 28, backgroundColor: kBrand, child: Text(initial, style: const TextStyle(color: Colors.white, fontSize: 24, fontWeight: FontWeight.w700))),
                const SizedBox(width: 16),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(s.name.isEmpty ? s.t('your_name') : s.name, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
                      Text('${s.xp} XP', style: const TextStyle(color: kBrandDark, fontWeight: FontWeight.w500)),
                    ],
                  ),
                ),
                const Icon(Icons.edit_outlined, color: kMuted, size: 20),
              ],
            ),
          ),
          _sectionTitle(s.t('my_language')),
          Wrap(
            spacing: 10,
            runSpacing: 10,
            children: [
              for (final l in kLangs)
                ChoiceChip(
                  label: Text(l.native),
                  selected: s.lang == l.code,
                  showCheckmark: false,
                  selectedColor: kBrand,
                  backgroundColor: Colors.white,
                  side: BorderSide(color: s.lang == l.code ? kBrand : kLine),
                  labelStyle: TextStyle(color: s.lang == l.code ? Colors.white : kInk, fontWeight: FontWeight.w600),
                  onSelected: (_) => s.setLang(l.code),
                ),
            ],
          ),
          _sectionTitle(s.t('daily_goal')),
          Wrap(
            spacing: 10,
            runSpacing: 10,
            children: [
              for (final m in [5, 10, 20])
                ChoiceChip(
                  label: Text('$m ${s.t('min')}'),
                  selected: s.goalMin == m,
                  showCheckmark: false,
                  selectedColor: kBrand,
                  backgroundColor: Colors.white,
                  side: BorderSide(color: s.goalMin == m ? kBrand : kLine),
                  labelStyle: TextStyle(color: s.goalMin == m ? Colors.white : kInk, fontWeight: FontWeight.w600),
                  onSelected: (_) => s.setGoal(m),
                ),
            ],
          ),
          const SizedBox(height: 22),
          Panel(
            onTap: () => push(context, const AiSettingsScreen()),
            child: Row(
              children: [
                const Icon(Icons.smart_toy_outlined, color: kBrand),
                const SizedBox(width: 14),
                Expanded(child: Text(s.t('ai_settings'), style: const TextStyle(fontWeight: FontWeight.w600))),
                const Icon(Icons.chevron_right, color: kMuted),
              ],
            ),
          ),
          const SizedBox(height: 12),
          Panel(
            onTap: () async {
              if (await confirmDialog(context, s.t('reset_q'))) await s.resetAll();
            },
            child: Row(
              children: [
                const Icon(Icons.restart_alt_rounded, color: kRed),
                const SizedBox(width: 14),
                Expanded(child: Text(s.t('reset'), style: const TextStyle(fontWeight: FontWeight.w600, color: kRed))),
              ],
            ),
          ),
          _sectionTitle(s.t('about')),
          Panel(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Container(
                      width: 46,
                      height: 46,
                      decoration: BoxDecoration(color: kBrand, borderRadius: BorderRadius.circular(14)),
                      child: const Icon(Icons.record_voice_over_rounded, color: Colors.white),
                    ),
                    const SizedBox(width: 12),
                    const Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('Spoken English Mastery', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 16)),
                          Text('v1.0.0', style: TextStyle(color: kMuted, fontSize: 12.5)),
                        ],
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 16),
                Text(s.t('developer'), style: const TextStyle(color: kMuted, fontSize: 12.5)),
                const Text('Torikul Islam', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w700)),
                const SizedBox(height: 4),
                const Text('WhatsApp: 01943264454', style: TextStyle(fontWeight: FontWeight.w500)),
                const SizedBox(height: 12),
                Row(
                  children: [
                    Expanded(
                      child: FilledButton.icon(
                        style: FilledButton.styleFrom(minimumSize: const Size(0, 46)),
                        onPressed: () async {
                          try {
                            final ok = await launchUrl(Uri.parse('https://wa.me/8801943264454'), mode: LaunchMode.externalApplication);
                            if (!ok && context.mounted) toast(context, '01943264454');
                          } catch (_) {
                            await Clipboard.setData(const ClipboardData(text: '01943264454'));
                            if (context.mounted) toast(context, '01943264454');
                          }
                        },
                        icon: const Icon(Icons.chat_rounded, size: 20),
                        label: Text(s.t('contact')),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
