import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../data.dart';
import '../speech.dart';
import '../store.dart';
import '../theme.dart';
import '../widgets.dart';
import 'ai_chat.dart';
import 'review.dart';

class PracticeScreen extends StatelessWidget {
  const PracticeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppState>();
    final due = s.dueCards().length;

    Widget tile(IconData icon, Color color, String title, String sub, VoidCallback onTap, {String? badge}) => Panel(
          margin: const EdgeInsets.only(bottom: 14),
          onTap: onTap,
          child: Row(
            children: [
              Container(
                width: 58,
                height: 58,
                decoration: BoxDecoration(color: color.withAlpha(28), borderRadius: BorderRadius.circular(18)),
                child: Icon(icon, color: color, size: 30),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(title, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 16.5)),
                    const SizedBox(height: 3),
                    Text(sub, style: const TextStyle(color: kMuted, fontSize: 13, height: 1.35)),
                  ],
                ),
              ),
              if (badge != null) Pill(badge),
            ],
          ),
        );

    return Scaffold(
      appBar: AppBar(title: Text(s.t('nav_practice'))),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(18, 8, 18, 24),
        children: [
          tile(Icons.smart_toy_rounded, kBrand, s.t('ai_partner'), s.t('ai_partner_sub'), () => push(context, const AiScenarioScreen())),
          tile(Icons.hearing_rounded, kBlue, s.t('sound_lab'), s.t('sound_lab_sub'), () => push(context, const SoundLabScreen())),
          tile(Icons.style_rounded, const Color(0xFFE59F00), s.t('review'), due > 0 ? s.t('cards_due', vars: {'n': '$due'}) : s.t('no_cards'),
              () => push(context, const ReviewScreen()),
              badge: due > 0 ? '$due' : null),
        ],
      ),
    );
  }
}

class Pill extends StatelessWidget {
  const Pill(this.text, {super.key});
  final String text;
  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
        decoration: BoxDecoration(color: kBrand, borderRadius: BorderRadius.circular(14)),
        child: Text(text, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700, fontSize: 12.5)),
      );
}

class SoundLabScreen extends StatelessWidget {
  const SoundLabScreen({super.key});
  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppState>();
    return Scaffold(
      appBar: AppBar(title: Text(s.t('sound_lab'))),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(18, 4, 18, 24),
        children: [
          for (final g in kSoundGroups)
            Panel(
              margin: const EdgeInsets.only(bottom: 12),
              onTap: () => push(context, SoundGroupScreen(group: g)),
              child: Row(
                children: [
                  Container(
                    width: 48,
                    height: 48,
                    decoration: BoxDecoration(color: kMint, borderRadius: BorderRadius.circular(14)),
                    child: const Icon(Icons.graphic_eq_rounded, color: kBrandDark),
                  ),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(g.title, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 16)),
                        Text(g.words.take(4).join(', '), style: const TextStyle(color: kMuted, fontSize: 13)),
                      ],
                    ),
                  ),
                  const Icon(Icons.chevron_right, color: kMuted),
                ],
              ),
            ),
        ],
      ),
    );
  }
}

class SoundGroupScreen extends StatelessWidget {
  const SoundGroupScreen({super.key, required this.group});
  final SoundGroup group;

  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppState>();
    final sp = context.read<SpeechService>();
    return Scaffold(
      appBar: AppBar(title: Text(group.title)),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(18, 4, 18, 24),
        children: [
          Panel(
            color: kMint,
            borderColor: kBrand.withAlpha(50),
            child: Directionality(
              textDirection: s.langInfo.rtl ? TextDirection.rtl : TextDirection.ltr,
              child: Text(soundTip(group, s.lang), style: const TextStyle(fontSize: 15, height: 1.5)),
            ),
          ),
          const SizedBox(height: 14),
          for (final w in group.words)
            Panel(
              margin: const EdgeInsets.only(bottom: 10),
              padding: const EdgeInsets.fromLTRB(16, 10, 12, 10),
              child: Row(
                children: [
                  SizedBox(width: 84, child: Text(w, style: const TextStyle(fontSize: 19, fontWeight: FontWeight.w600))),
                  IconButton(icon: const Icon(Icons.volume_up_rounded, color: kBrandDark), onPressed: () => sp.speak(w, slow: true)),
                  Expanded(child: SpeakPractice(key: ValueKey('w-$w'), target: w, compact: true, onScore: (_) {})),
                ],
              ),
            ),
        ],
      ),
    );
  }
}
