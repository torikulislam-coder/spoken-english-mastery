import 'dart:math';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../data.dart';
import '../speech.dart';
import '../store.dart';
import '../theme.dart';
import '../widgets.dart';

enum _Phase { learn, speak, quiz, done }

class _Q {
  final String? nativePrompt;
  final String? audio;
  final List<String> options;
  final int answer;
  _Q(this.nativePrompt, this.audio, this.options, this.answer);
}

class LessonScreen extends StatefulWidget {
  const LessonScreen({super.key, required this.lesson});
  final Lesson lesson;
  @override
  State<LessonScreen> createState() => _LessonScreenState();
}

class _LessonScreenState extends State<LessonScreen> {
  _Phase phase = _Phase.learn;
  int i = 0;
  final Map<String, double> acc = {};
  int attempts = 0;
  bool passed = false;
  bool reveal = false;
  late List<_Q> quiz;
  int qi = 0;
  int? picked;
  int correct = 0;
  int stars = 0;
  int earned = 0;
  double finalAcc = 0;
  final _rng = Random();
  late final SpeechService _sp;

  List<Phrase> get ps => widget.lesson.phrases;

  @override
  void initState() {
    super.initState();
    _sp = context.read<SpeechService>();
    quiz = _buildQuiz(context.read<AppState>().lang);
    WidgetsBinding.instance.addPostFrameCallback((_) => _say(ps[0].en));
  }

  @override
  void dispose() {
    // stop any speech when leaving
    Future.microtask(_sp.stopSpeaking);
    super.dispose();
  }

  void _say(String text, {bool slow = false}) {
    if (!mounted) return;
    context.read<SpeechService>().speak(text, slow: slow);
  }

  List<_Q> _buildQuiz(String lang) {
    final shuffled = [...ps]..shuffle(_rng);
    final n = min(6, shuffled.length);
    final qs = <_Q>[];
    for (var k = 0; k < n; k++) {
      final p = shuffled[k];
      final others = ps.where((x) => x.id != p.id).toList()..shuffle(_rng);
      final opts = <String>[p.en, ...others.take(3).map((x) => x.en)]..shuffle(_rng);
      final nativeQ = lang != 'en' && k.isEven;
      qs.add(_Q(nativeQ ? p.native(lang) : null, nativeQ ? null : p.en, opts, opts.indexOf(p.en)));
    }
    return qs;
  }

  double get _progress {
    final n = ps.length;
    final total = n + n + quiz.length;
    switch (phase) {
      case _Phase.learn:
        return i / total;
      case _Phase.speak:
        return (n + i) / total;
      case _Phase.quiz:
        return (2 * n + qi) / total;
      case _Phase.done:
        return 1;
    }
  }

  // ---------------------------------------------------------------- learn
  void _nextLearn() {
    if (i + 1 < ps.length) {
      setState(() => i++);
      _say(ps[i].en);
    } else {
      setState(() {
        phase = _Phase.speak;
        i = 0;
        attempts = 0;
        passed = false;
        reveal = false;
      });
    }
  }

  // ---------------------------------------------------------------- speak
  void _onScore(double pct) {
    final p = ps[i];
    setState(() {
      attempts++;
      if (pct < 0) {
        acc[p.id] = 0.75;
        passed = true;
      } else {
        acc[p.id] = max(acc[p.id] ?? 0, pct);
        if (pct >= 0.7) passed = true;
      }
      if (attempts >= 2) reveal = true;
    });
  }

  void _nextSpeak() {
    if (i + 1 < ps.length) {
      setState(() {
        i++;
        attempts = 0;
        passed = false;
        reveal = false;
      });
    } else {
      setState(() {
        phase = _Phase.quiz;
        qi = 0;
        picked = null;
      });
      _quizEnter();
    }
  }

  // ----------------------------------------------------------------- quiz
  void _quizEnter() {
    final q = quiz[qi];
    if (q.audio != null) _say(q.audio!);
  }

  void _pick(int j) {
    if (picked != null) return;
    setState(() {
      picked = j;
      if (j == quiz[qi].answer) correct++;
    });
  }

  Future<void> _nextQuiz() async {
    if (qi + 1 < quiz.length) {
      setState(() {
        qi++;
        picked = null;
      });
      _quizEnter();
    } else {
      await _finish();
    }
  }

  Future<void> _finish() async {
    final s = context.read<AppState>();
    var sum = 0.0;
    for (final p in ps) {
      sum += acc[p.id] ?? 0;
    }
    final speakAcc = ps.isEmpty ? 0.0 : sum / ps.length;
    final quizAcc = quiz.isEmpty ? 0.0 : correct / quiz.length;
    final combined = 0.5 * speakAcc + 0.5 * quizAcc;
    stars = combined >= 0.85 ? 3 : (combined >= 0.6 ? 2 : 1);
    earned = 10 + correct * 2 + stars * 5;
    finalAcc = combined;
    await s.completeLesson(widget.lesson, stars, earned);
    if (!mounted) return;
    setState(() => phase = _Phase.done);
  }

  // ------------------------------------------------------------------ UI
  Widget _top(AppState s) => Padding(
        padding: const EdgeInsets.fromLTRB(8, 6, 18, 6),
        child: Row(
          children: [
            IconButton(
              icon: const Icon(Icons.close_rounded),
              onPressed: () async {
                if (phase == _Phase.done) {
                  Navigator.pop(context);
                  return;
                }
                if (await confirmDialog(context, s.t('quit_q'))) {
                  if (mounted) Navigator.pop(context);
                }
              },
            ),
            Expanded(
              child: ClipRRect(
                borderRadius: BorderRadius.circular(8),
                child: TweenAnimationBuilder<double>(
                  tween: Tween(begin: 0, end: _progress),
                  duration: const Duration(milliseconds: 350),
                  builder: (_, v, __) => LinearProgressIndicator(value: v, minHeight: 10, backgroundColor: kLine, color: kBrand),
                ),
              ),
            ),
          ],
        ),
      );

  Widget _label(String text) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
        decoration: BoxDecoration(color: kMint, borderRadius: BorderRadius.circular(20)),
        child: Text(text, style: const TextStyle(color: kBrandDark, fontWeight: FontWeight.w600, fontSize: 13)),
      );

  Widget _bottom(Widget child) => Padding(
        padding: const EdgeInsets.fromLTRB(20, 8, 20, 18),
        child: SizedBox(width: double.infinity, child: child),
      );

  Widget _learnView(AppState s) {
    final p = ps[i];
    return Column(
      children: [
        Expanded(
          child: ListView(
            padding: const EdgeInsets.fromLTRB(20, 10, 20, 10),
            children: [
              Align(alignment: Alignment.centerLeft, child: _label('${s.t('step_learn')}  ${i + 1}/${ps.length}')),
              const SizedBox(height: 18),
              Panel(
                padding: const EdgeInsets.fromLTRB(22, 34, 22, 28),
                onTap: () => _say(p.en),
                child: Column(
                  children: [
                    Text(p.en, textAlign: TextAlign.center, style: const TextStyle(fontSize: 28, fontWeight: FontWeight.w700, height: 1.25)),
                    if (s.lang != 'en') ...[
                      const SizedBox(height: 18),
                      Container(height: 1.5, width: 60, color: kLine),
                      const SizedBox(height: 18),
                      NativeText(p.native(s.lang), s.lang, style: const TextStyle(fontSize: 21, color: kBrandDark, fontWeight: FontWeight.w500, height: 1.4)),
                    ],
                  ],
                ),
              ),
              const SizedBox(height: 26),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  RoundIcon(icon: Icons.volume_up_rounded, label: s.t('listen'), filled: true, onTap: () => _say(p.en)),
                  const SizedBox(width: 28),
                  RoundIcon(icon: Icons.slow_motion_video_rounded, label: s.t('slow'), onTap: () => _say(p.en, slow: true)),
                ],
              ),
            ],
          ),
        ),
        _bottom(FilledButton(onPressed: _nextLearn, child: Text(s.t('next')))),
      ],
    );
  }

  Widget _speakView(AppState s) {
    final p = ps[i];
    final native = s.lang != 'en';
    return Column(
      children: [
        Expanded(
          child: ListView(
            padding: const EdgeInsets.fromLTRB(20, 10, 20, 10),
            children: [
              Align(alignment: Alignment.centerLeft, child: _label('${s.t('step_speak')}  ${i + 1}/${ps.length}')),
              const SizedBox(height: 16),
              Text(native ? s.t('say_it') : s.t('repeat_it'), style: const TextStyle(color: kMuted, fontWeight: FontWeight.w500)),
              const SizedBox(height: 10),
              Panel(
                padding: const EdgeInsets.fromLTRB(20, 26, 20, 22),
                child: Column(
                  children: [
                    if (native)
                      NativeText(p.native(s.lang), s.lang, style: const TextStyle(fontSize: 23, fontWeight: FontWeight.w600, height: 1.35))
                    else
                      Text(p.en, textAlign: TextAlign.center, style: const TextStyle(fontSize: 25, fontWeight: FontWeight.w700, height: 1.3)),
                    if (native && (reveal || attempts >= 2)) ...[
                      const SizedBox(height: 14),
                      Text(p.en, textAlign: TextAlign.center, style: const TextStyle(fontSize: 18, color: kBrandDark, fontWeight: FontWeight.w600)),
                    ],
                    const SizedBox(height: 14),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        RoundIcon(icon: Icons.volume_up_rounded, size: 46, onTap: () => _say(p.en)),
                        if (native && !reveal) ...[
                          const SizedBox(width: 12),
                          TextButton(onPressed: () => setState(() => reveal = true), child: Text(s.t('show_answer'))),
                        ],
                      ],
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 22),
              SpeakPractice(key: ValueKey('sp-${p.id}'), target: p.en, onScore: _onScore),
            ],
          ),
        ),
        _bottom(
          (passed || attempts >= 3)
              ? FilledButton(onPressed: _nextSpeak, child: Text(s.t('next')))
              : TextButton(onPressed: _nextSpeak, child: Text(s.t('skip'))),
        ),
      ],
    );
  }

  Widget _quizView(AppState s) {
    final q = quiz[qi];
    return Column(
      children: [
        Expanded(
          child: ListView(
            padding: const EdgeInsets.fromLTRB(20, 10, 20, 10),
            children: [
              Align(alignment: Alignment.centerLeft, child: _label('${s.t('step_quiz')}  ${qi + 1}/${quiz.length}')),
              const SizedBox(height: 16),
              Text(q.audio != null ? s.t('pick_heard') : s.t('pick_english'), style: const TextStyle(color: kMuted, fontWeight: FontWeight.w500)),
              const SizedBox(height: 10),
              if (q.nativePrompt != null)
                Panel(
                  padding: const EdgeInsets.all(24),
                  child: NativeText(q.nativePrompt!, s.lang, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w600, height: 1.35)),
                )
              else
                Panel(
                  padding: const EdgeInsets.symmetric(vertical: 24),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      RoundIcon(icon: Icons.volume_up_rounded, filled: true, size: 64, onTap: () => _say(q.audio!)),
                      const SizedBox(width: 22),
                      RoundIcon(icon: Icons.slow_motion_video_rounded, size: 50, onTap: () => _say(q.audio!, slow: true)),
                    ],
                  ),
                ),
              const SizedBox(height: 18),
              for (var j = 0; j < q.options.length; j++) _option(q, j),
            ],
          ),
        ),
        _bottom(FilledButton(onPressed: picked == null ? null : _nextQuiz, child: Text(s.t('next')))),
      ],
    );
  }

  Widget _option(_Q q, int j) {
    Color border = kLine;
    Color bg = Colors.white;
    IconData? icon;
    if (picked != null) {
      if (j == q.answer) {
        border = kBrand;
        bg = kMint;
        icon = Icons.check_circle;
      } else if (j == picked) {
        border = kRed;
        bg = kRed.withAlpha(18);
        icon = Icons.cancel;
      }
    }
    return Panel(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 15),
      borderColor: border,
      color: bg,
      radius: 18,
      onTap: () => _pick(j),
      child: Row(
        children: [
          Expanded(child: Text(q.options[j], style: const TextStyle(fontSize: 16.5, fontWeight: FontWeight.w500))),
          if (icon != null) Icon(icon, color: j == q.answer ? kBrand : kRed),
        ],
      ),
    );
  }

  Widget _doneView(AppState s) {
    return Column(
      children: [
        Expanded(
          child: Center(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(24),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  TweenAnimationBuilder<double>(
                    tween: Tween(begin: 0.3, end: 1),
                    duration: const Duration(milliseconds: 700),
                    curve: Curves.elasticOut,
                    builder: (_, v, __) => Transform.scale(
                      scale: v,
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          for (var k = 0; k < 3; k++)
                            Icon(k < stars ? Icons.star_rounded : Icons.star_outline_rounded, color: kGold, size: k == 1 ? 84 : 64),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 22),
                  Text(s.t('done_title'), textAlign: TextAlign.center, style: const TextStyle(fontSize: 26, fontWeight: FontWeight.w700)),
                  const SizedBox(height: 8),
                  Text(widget.lesson.name(s.lang), textAlign: TextAlign.center, style: const TextStyle(color: kMuted)),
                  const SizedBox(height: 24),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      StatChip(Icons.bolt, s.t('earned', vars: {'n': '$earned'}), dark: false),
                    ],
                  ),
                  const SizedBox(height: 10),
                  StatChip(Icons.track_changes, '${s.t('accuracy')}: ${(finalAcc * 100).round()}%', color: kBrand, dark: false),
                ],
              ),
            ),
          ),
        ),
        _bottom(FilledButton(onPressed: () => Navigator.pop(context), child: Text(s.t('back_path')))),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppState>();
    Widget body;
    switch (phase) {
      case _Phase.learn:
        body = _learnView(s);
        break;
      case _Phase.speak:
        body = _speakView(s);
        break;
      case _Phase.quiz:
        body = _quizView(s);
        break;
      case _Phase.done:
        body = _doneView(s);
        break;
    }
    return Scaffold(
      body: SafeArea(child: Column(children: [_top(s), Expanded(child: body)])),
    );
  }
}
