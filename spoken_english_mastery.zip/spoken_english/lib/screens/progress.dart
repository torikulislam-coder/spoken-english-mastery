import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../store.dart';
import '../theme.dart';
import '../widgets.dart';

class ProgressScreen extends StatelessWidget {
  const ProgressScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppState>();
    final today = epochDay();
    final week = [for (var d = 6; d >= 0; d--) (today - d)];
    var maxXp = 1;
    for (final d in week) {
      final v = s.daily['$d'] ?? 0;
      if (v > maxXp) maxXp = v;
    }

    Widget stat(IconData icon, Color c, String value, String label) => Expanded(
          child: Panel(
            padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 12),
            child: Column(
              children: [
                Icon(icon, color: c, size: 26),
                const SizedBox(height: 8),
                Text(value, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w700)),
                const SizedBox(height: 2),
                Text(label, textAlign: TextAlign.center, style: const TextStyle(color: kMuted, fontSize: 12, height: 1.25)),
              ],
            ),
          ),
        );

    return Scaffold(
      appBar: AppBar(title: Text(s.t('nav_progress'))),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(18, 4, 18, 24),
        children: [
          Row(
            children: [
              stat(Icons.bolt, kGold, '${s.xp}', 'XP'),
              const SizedBox(width: 12),
              stat(Icons.local_fire_department, const Color(0xFFFF7A2F), '${s.streak}', s.t('streak')),
              const SizedBox(width: 12),
              stat(Icons.emoji_events_rounded, kBrand, '${s.bestStreak}', s.t('best_streak')),
            ],
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              stat(Icons.check_circle_rounded, kBrand, '${s.lessonsDone}', s.t('lessons_done')),
              const SizedBox(width: 12),
              stat(Icons.chat_bubble_rounded, kBlue, '${s.phrasesLearned}', s.t('words_learned')),
            ],
          ),
          const SizedBox(height: 22),
          Text(s.t('this_week'), style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w700)),
          const SizedBox(height: 10),
          Panel(
            padding: const EdgeInsets.fromLTRB(16, 20, 16, 14),
            child: SizedBox(
              height: 140,
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.end,
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  for (final d in week)
                    Builder(builder: (_) {
                      final v = s.daily['$d'] ?? 0;
                      final dt = DateTime.fromMillisecondsSinceEpoch(d * 86400000, isUtc: true);
                      final isToday = d == today;
                      return Column(
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: [
                          Text(v > 0 ? '$v' : '', style: const TextStyle(fontSize: 11, color: kMuted)),
                          const SizedBox(height: 4),
                          AnimatedContainer(
                            duration: const Duration(milliseconds: 400),
                            width: 26,
                            height: 8 + 80.0 * v / maxXp,
                            decoration: BoxDecoration(
                              color: v == 0 ? kLine : (isToday ? kBrand : kBrand.withAlpha(150)),
                              borderRadius: BorderRadius.circular(8),
                            ),
                          ),
                          const SizedBox(height: 8),
                          Text('${dt.day}', style: TextStyle(fontSize: 12, fontWeight: isToday ? FontWeight.w700 : FontWeight.w400, color: isToday ? kBrandDark : kMuted)),
                        ],
                      );
                    }),
                ],
              ),
            ),
          ),
          const SizedBox(height: 22),
          Text(s.t('levels'), style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w700)),
          const SizedBox(height: 10),
          for (final lv in s.content.levels)
            Panel(
              margin: const EdgeInsets.only(bottom: 10),
              padding: const EdgeInsets.fromLTRB(16, 14, 16, 14),
              child: Column(
                children: [
                  Row(
                    children: [
                      Expanded(child: Text('${s.t('level')} ${lv.id}: ${lv.name(s.lang)}', style: const TextStyle(fontWeight: FontWeight.w600))),
                      Text(lv.lessons.isEmpty ? s.t('coming_soon') : '${s.levelDone(lv)}/${lv.lessons.length}',
                          style: const TextStyle(color: kBrandDark, fontWeight: FontWeight.w600, fontSize: 13)),
                    ],
                  ),
                  const SizedBox(height: 10),
                  ClipRRect(
                    borderRadius: BorderRadius.circular(6),
                    child: LinearProgressIndicator(
                      value: lv.lessons.isEmpty ? 0 : s.levelDone(lv) / lv.lessons.length,
                      minHeight: 8,
                      backgroundColor: kLine,
                      color: kBrand,
                    ),
                  ),
                ],
              ),
            ),
        ],
      ),
    );
  }
}
