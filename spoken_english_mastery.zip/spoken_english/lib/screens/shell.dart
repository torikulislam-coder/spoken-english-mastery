import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../data.dart';
import '../store.dart';
import '../theme.dart';
import '../widgets.dart';
import 'lesson.dart';
import 'practice.dart';
import 'profile.dart';
import 'progress.dart';
import 'review.dart';

class Shell extends StatefulWidget {
  const Shell({super.key});
  @override
  State<Shell> createState() => _ShellState();
}

class _ShellState extends State<Shell> {
  int _i = 0;

  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppState>();
    return Scaffold(
      body: IndexedStack(
        index: _i,
        children: const [PathScreen(), PracticeScreen(), ProgressScreen(), ProfileScreen()],
      ),
      bottomNavigationBar: NavigationBar(
        backgroundColor: Colors.white,
        indicatorColor: kMint,
        selectedIndex: _i,
        onDestinationSelected: (v) => setState(() => _i = v),
        destinations: [
          NavigationDestination(icon: const Icon(Icons.route_outlined), selectedIcon: const Icon(Icons.route, color: kBrandDark), label: s.t('nav_path')),
          NavigationDestination(icon: const Icon(Icons.mic_none_rounded), selectedIcon: const Icon(Icons.mic_rounded, color: kBrandDark), label: s.t('nav_practice')),
          NavigationDestination(icon: const Icon(Icons.insights_outlined), selectedIcon: const Icon(Icons.insights, color: kBrandDark), label: s.t('nav_progress')),
          NavigationDestination(icon: const Icon(Icons.person_outline), selectedIcon: const Icon(Icons.person, color: kBrandDark), label: s.t('nav_profile')),
        ],
      ),
    );
  }
}

class PathScreen extends StatelessWidget {
  const PathScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppState>();
    final next = s.nextLesson;
    final due = s.dueCards().length;
    final goalRatio = s.goalXp == 0 ? 0.0 : (s.todayXp / s.goalXp > 1 ? 1.0 : s.todayXp / s.goalXp);

    return ListView(
      padding: EdgeInsets.zero,
      children: [
        Container(
          padding: EdgeInsets.fromLTRB(22, MediaQuery.of(context).padding.top + 16, 22, 24),
          decoration: const BoxDecoration(
            gradient: LinearGradient(colors: [kBrand, kBrandDark], begin: Alignment.topLeft, end: Alignment.bottomRight),
            borderRadius: BorderRadius.vertical(bottom: Radius.circular(32)),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(s.name.isEmpty ? s.t('hello') : '${s.t('hello')}, ${s.name}',
                  style: const TextStyle(color: Colors.white, fontSize: 24, fontWeight: FontWeight.w700)),
              const SizedBox(height: 14),
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: [
                  StatChip(Icons.local_fire_department, '${s.streak} ${s.t('streak')}'),
                  StatChip(Icons.bolt, '${s.xp} XP'),
                ],
              ),
              const SizedBox(height: 18),
              Row(
                children: [
                  Expanded(child: Text(s.t('today_goal'), style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w500))),
                  Text('${s.todayXp}/${s.goalXp} XP', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w600)),
                ],
              ),
              const SizedBox(height: 8),
              ClipRRect(
                borderRadius: BorderRadius.circular(8),
                child: LinearProgressIndicator(value: goalRatio, minHeight: 9, backgroundColor: Colors.white.withAlpha(50), color: kGold),
              ),
            ],
          ),
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(18, 18, 18, 0),
          child: Column(
            children: [
              if (next != null)
                Panel(
                  onTap: () => push(context, LessonScreen(lesson: next)),
                  child: Row(
                    children: [
                      Container(
                        width: 54,
                        height: 54,
                        decoration: BoxDecoration(color: kBrand, borderRadius: BorderRadius.circular(18)),
                        child: const Icon(Icons.play_arrow_rounded, color: Colors.white, size: 32),
                      ),
                      const SizedBox(width: 14),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(s.t('continue_learning'), style: const TextStyle(color: kMuted, fontSize: 12.5)),
                            const SizedBox(height: 2),
                            Text(next.name(s.lang), style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 16.5)),
                            Text('${s.t('level')} ${next.level}', style: const TextStyle(color: kBrandDark, fontSize: 12.5, fontWeight: FontWeight.w500)),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              if (due > 0) ...[
                const SizedBox(height: 12),
                Panel(
                  color: kMint,
                  borderColor: kBrand.withAlpha(60),
                  onTap: () => push(context, const ReviewScreen()),
                  child: Row(
                    children: [
                      const Icon(Icons.style_outlined, color: kBrandDark),
                      const SizedBox(width: 12),
                      Expanded(child: Text(s.t('review'), style: const TextStyle(fontWeight: FontWeight.w600))),
                      Text(s.t('cards_due', vars: {'n': '$due'}), style: const TextStyle(color: kBrandDark, fontWeight: FontWeight.w600, fontSize: 13)),
                    ],
                  ),
                ),
              ],
            ],
          ),
        ),
        for (final lv in s.content.levels) _LevelSection(level: lv),
        const SizedBox(height: 30),
      ],
    );
  }
}

class _LevelSection extends StatelessWidget {
  const _LevelSection({required this.level});
  final Level level;

  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppState>();
    final total = level.lessons.length;
    final done = s.levelDone(level);
    final soon = total == 0;
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(18, 26, 18, 14),
          child: Panel(
            color: soon ? Colors.white : kBrandDark,
            borderColor: soon ? kLine : kBrandDark,
            child: Row(
              children: [
                Container(
                  width: 46,
                  height: 46,
                  alignment: Alignment.center,
                  decoration: BoxDecoration(color: soon ? kMint : Colors.white.withAlpha(36), borderRadius: BorderRadius.circular(14)),
                  child: Text('${level.id}', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w700, color: soon ? kBrandDark : Colors.white)),
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('${s.t('level')} ${level.id}: ${level.name(s.lang)}',
                          style: TextStyle(fontWeight: FontWeight.w700, fontSize: 16, color: soon ? kInk : Colors.white)),
                      const SizedBox(height: 2),
                      Text(level.topic(s.lang), style: TextStyle(fontSize: 12.5, height: 1.3, color: soon ? kMuted : Colors.white70)),
                    ],
                  ),
                ),
                const SizedBox(width: 8),
                if (soon)
                  const Icon(Icons.lock_clock, color: kMuted)
                else
                  Text('$done/$total', style: const TextStyle(color: kGold, fontWeight: FontWeight.w700)),
              ],
            ),
          ),
        ),
        if (soon)
          Padding(
            padding: const EdgeInsets.only(bottom: 4),
            child: Text(s.t('coming_soon'), style: const TextStyle(color: kMuted, fontWeight: FontWeight.w500)),
          ),
        for (var i = 0; i < level.lessons.length; i++) _Node(lesson: level.lessons[i], i: i),
      ],
    );
  }
}

class _Node extends StatelessWidget {
  const _Node({required this.lesson, required this.i});
  final Lesson lesson;
  final int i;

  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppState>();
    final done = s.isDone(lesson);
    final open = s.isUnlocked(lesson);
    final stars = s.done[lesson.id] ?? 0;
    final dx = math.sin(i * 1.15) * 0.55;
    final color = done ? kBrand : (open ? kBrand : const Color(0xFFD5DDD9));
    return Align(
      alignment: Alignment(dx, 0),
      child: Padding(
        padding: const EdgeInsets.only(bottom: 22),
        child: GestureDetector(
          onTap: () {
            if (open) {
              push(context, LessonScreen(lesson: lesson));
            } else {
              toast(context, s.t('locked'));
            }
          },
          child: SizedBox(
            width: 170,
            child: Column(
              children: [
                Container(
                  width: 82,
                  height: 82,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: color,
                    border: Border.all(color: open && !done ? kGold : Colors.white, width: 5),
                    boxShadow: [BoxShadow(color: color.withAlpha(90), blurRadius: 16, offset: const Offset(0, 8))],
                  ),
                  child: Icon(done ? Icons.check_rounded : (open ? Icons.play_arrow_rounded : Icons.lock_rounded), color: Colors.white, size: 38),
                ),
                const SizedBox(height: 8),
                if (done)
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [for (var k = 0; k < 3; k++) Icon(k < stars ? Icons.star_rounded : Icons.star_outline_rounded, color: kGold, size: 18)],
                  ),
                Text(lesson.name(s.lang), textAlign: TextAlign.center, maxLines: 2, overflow: TextOverflow.ellipsis,
                    style: TextStyle(fontWeight: FontWeight.w600, fontSize: 13.5, color: open ? kInk : kMuted, height: 1.3)),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
