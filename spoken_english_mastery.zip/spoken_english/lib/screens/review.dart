import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../data.dart';
import '../speech.dart';
import '../store.dart';
import '../theme.dart';
import '../widgets.dart';

class ReviewScreen extends StatefulWidget {
  const ReviewScreen({super.key});
  @override
  State<ReviewScreen> createState() => _ReviewScreenState();
}

class _ReviewScreenState extends State<ReviewScreen> {
  late List<Phrase> cards;
  int i = 0;
  bool flipped = false;
  int good = 0;
  bool finished = false;

  @override
  void initState() {
    super.initState();
    cards = context.read<AppState>().dueCards()..shuffle();
    if (cards.length > 20) cards = cards.sublist(0, 20);
    if (context.read<AppState>().lang == 'en' && cards.isNotEmpty) {
      WidgetsBinding.instance.addPostFrameCallback((_) => _say(cards[0].en));
    }
  }

  void _say(String t, {bool slow = false}) {
    if (!mounted) return;
    context.read<SpeechService>().speak(t, slow: slow);
  }

  Future<void> _answer(bool ok) async {
    final s = context.read<AppState>();
    await s.reviewResult(cards[i].id, ok);
    if (ok) good++;
    if (i + 1 < cards.length) {
      setState(() {
        i++;
        flipped = false;
      });
      if (s.lang == 'en') _say(cards[i].en);
    } else {
      await s.addXp(good + 2);
      if (mounted) setState(() => finished = true);
    }
  }

  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppState>();
    Widget body;
    if (cards.isEmpty) {
      body = Center(child: Padding(padding: const EdgeInsets.all(30), child: Text(s.t('no_cards'), textAlign: TextAlign.center, style: const TextStyle(color: kMuted, height: 1.5))));
    } else if (finished) {
      body = Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.emoji_events_rounded, color: kGold, size: 84),
            const SizedBox(height: 14),
            Text(s.t('great'), style: const TextStyle(fontSize: 26, fontWeight: FontWeight.w700)),
            const SizedBox(height: 8),
            Text('$good / ${cards.length}', style: const TextStyle(fontSize: 18, color: kBrandDark, fontWeight: FontWeight.w600)),
            const SizedBox(height: 24),
            FilledButton(onPressed: () => Navigator.pop(context), child: Text(s.t('back_path'))),
          ],
        ),
      );
    } else {
      final p = cards[i];
      final native = s.lang != 'en';
      body = Column(
        children: [
          Expanded(
            child: ListView(
              padding: const EdgeInsets.fromLTRB(20, 10, 20, 10),
              children: [
                ClipRRect(
                  borderRadius: BorderRadius.circular(8),
                  child: LinearProgressIndicator(value: i / cards.length, minHeight: 8, backgroundColor: kLine, color: kBrand),
                ),
                const SizedBox(height: 22),
                Panel(
                  padding: const EdgeInsets.fromLTRB(22, 40, 22, 34),
                  child: Column(
                    children: [
                      if (native)
                        NativeText(p.native(s.lang), s.lang, style: const TextStyle(fontSize: 23, fontWeight: FontWeight.w600, height: 1.4))
                      else if (!flipped)
                        RoundIcon(icon: Icons.volume_up_rounded, filled: true, size: 66, onTap: () => _say(p.en)),
                      if (flipped) ...[
                        if (native) const SizedBox(height: 20),
                        Text(p.en, textAlign: TextAlign.center, style: const TextStyle(fontSize: 26, fontWeight: FontWeight.w700, color: kBrandDark, height: 1.3)),
                        const SizedBox(height: 16),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            RoundIcon(icon: Icons.volume_up_rounded, size: 48, onTap: () => _say(p.en)),
                            const SizedBox(width: 14),
                            RoundIcon(icon: Icons.slow_motion_video_rounded, size: 48, onTap: () => _say(p.en, slow: true)),
                          ],
                        ),
                      ],
                    ],
                  ),
                ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 8, 20, 18),
            child: flipped
                ? Row(
                    children: [
                      Expanded(child: OutlinedButton(onPressed: () => _answer(false), child: Text(s.t('again')))),
                      const SizedBox(width: 12),
                      Expanded(child: FilledButton(onPressed: () => _answer(true), child: Text(s.t('good')))),
                    ],
                  )
                : SizedBox(
                    width: double.infinity,
                    child: FilledButton(
                      onPressed: () {
                        setState(() => flipped = true);
                        _say(p.en);
                      },
                      child: Text(s.t('show_answer')),
                    ),
                  ),
          ),
        ],
      );
    }
    return Scaffold(appBar: AppBar(title: Text(s.t('review'))), body: SafeArea(child: body));
  }
}
