import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../l10n.dart';
import '../store.dart';
import '../theme.dart';
import '../widgets.dart';

class OnboardingScreen extends StatefulWidget {
  const OnboardingScreen({super.key});
  @override
  State<OnboardingScreen> createState() => _OnboardingScreenState();
}

class _OnboardingScreenState extends State<OnboardingScreen> {
  int page = 0;
  String lang = 'bn';
  int goal = 10;
  final name = TextEditingController();

  String t(String k, {Map<String, String>? vars}) => tr(k, lang, vars: vars);

  Widget _langTile(Lang l) {
    final sel = l.code == lang;
    return Panel(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 14),
      borderColor: sel ? kBrand : kLine,
      color: sel ? kMint : Colors.white,
      onTap: () => setState(() => lang = l.code),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(l.native, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w600)),
                Text(l.english, style: const TextStyle(color: kMuted, fontSize: 12.5)),
              ],
            ),
          ),
          Icon(sel ? Icons.check_circle : Icons.circle_outlined, color: sel ? kBrand : kLine, size: 26),
        ],
      ),
    );
  }

  Widget _goalTile(String key, int min) {
    final sel = goal == min;
    return Panel(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 14),
      borderColor: sel ? kBrand : kLine,
      color: sel ? kMint : Colors.white,
      onTap: () => setState(() => goal = min),
      child: Row(
        children: [
          Expanded(child: Text(t(key), style: const TextStyle(fontSize: 16.5, fontWeight: FontWeight.w600))),
          Text('$min ${t('min')}', style: const TextStyle(color: kBrandDark, fontWeight: FontWeight.w600)),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final s = context.read<AppState>();
    return Scaffold(
      backgroundColor: kBg,
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(22, 18, 22, 22),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                child: ListView(
                  children: page == 0
                      ? [
                          Container(
                            width: 72,
                            height: 72,
                            decoration: BoxDecoration(
                              gradient: const LinearGradient(colors: [kBrand, kBrandDark], begin: Alignment.topCenter, end: Alignment.bottomCenter),
                              borderRadius: BorderRadius.circular(22),
                            ),
                            child: const Icon(Icons.record_voice_over_rounded, color: Colors.white, size: 38),
                          ),
                          const SizedBox(height: 18),
                          const Text('Spoken English Mastery', style: TextStyle(fontSize: 27, fontWeight: FontWeight.w700, height: 1.2)),
                          const SizedBox(height: 10),
                          Text(t('welcome_title'), style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w600, color: kBrandDark)),
                          const SizedBox(height: 4),
                          Text(t('welcome_sub'), style: const TextStyle(color: kMuted, height: 1.4)),
                          const SizedBox(height: 26),
                          Text(t('choose_lang'), style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
                          const SizedBox(height: 2),
                          Text(t('choose_lang_sub'), style: const TextStyle(color: kMuted, fontSize: 13)),
                          const SizedBox(height: 14),
                          for (final l in kLangs) _langTile(l),
                        ]
                      : [
                          const SizedBox(height: 10),
                          Text(t('your_name'), style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
                          const SizedBox(height: 12),
                          TextField(controller: name, textCapitalization: TextCapitalization.words),
                          const SizedBox(height: 28),
                          Text(t('daily_goal'), style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
                          const SizedBox(height: 12),
                          _goalTile('goal_casual', 5),
                          _goalTile('goal_regular', 10),
                          _goalTile('goal_serious', 20),
                        ],
                ),
              ),
              SizedBox(
                width: double.infinity,
                child: FilledButton(
                  onPressed: () async {
                    if (page == 0) {
                      setState(() => page = 1);
                    } else {
                      await s.finishOnboarding(lang, name.text, goal);
                    }
                  },
                  child: Text(page == 0 ? t('continue_btn') : t('start')),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
