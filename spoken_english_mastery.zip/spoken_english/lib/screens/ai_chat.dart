import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:provider/provider.dart';
import '../speech.dart';
import '../store.dart';
import '../theme.dart';
import '../widgets.dart';

class _Scenario {
  final String key;
  final String english;
  final IconData icon;
  const _Scenario(this.key, this.english, this.icon);
}

const _scenarios = [
  _Scenario('sc_cafe', 'ordering food and drinks at a cafe', Icons.local_cafe_rounded),
  _Scenario('sc_shop', 'shopping for clothes in a shop', Icons.shopping_bag_rounded),
  _Scenario('sc_airport', 'checking in and travelling at an airport', Icons.flight_takeoff_rounded),
  _Scenario('sc_interview', 'a simple job interview', Icons.work_rounded),
  _Scenario('sc_doctor', 'visiting a doctor', Icons.local_hospital_rounded),
  _Scenario('sc_chat', 'free everyday conversation about daily life', Icons.forum_rounded),
];

class AiScenarioScreen extends StatelessWidget {
  const AiScenarioScreen({super.key});
  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppState>();
    return Scaffold(
      appBar: AppBar(
        title: Text(s.t('ai_partner')),
        actions: [IconButton(icon: const Icon(Icons.settings_outlined), onPressed: () => push(context, const AiSettingsScreen()))],
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(18, 4, 18, 24),
        children: [
          Text(s.t('ai_note'), style: const TextStyle(color: kMuted, fontSize: 13)),
          const SizedBox(height: 14),
          for (final sc in _scenarios)
            Panel(
              margin: const EdgeInsets.only(bottom: 12),
              onTap: () => push(context, AiChatScreen(scenario: sc)),
              child: Row(
                children: [
                  Container(
                    width: 50,
                    height: 50,
                    decoration: BoxDecoration(color: kMint, borderRadius: BorderRadius.circular(16)),
                    child: Icon(sc.icon, color: kBrandDark),
                  ),
                  const SizedBox(width: 14),
                  Expanded(child: Text(s.t(sc.key), style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 16))),
                  const Icon(Icons.chevron_right, color: kMuted),
                ],
              ),
            ),
        ],
      ),
    );
  }
}

class _Msg {
  final bool user;
  final bool hidden;
  final String text;
  final String raw;
  String correction;
  String note;
  _Msg({required this.user, this.hidden = false, required this.text, this.raw = '', this.correction = '', this.note = ''});
}

class AiChatScreen extends StatefulWidget {
  const AiChatScreen({super.key, required this.scenario});
  final _Scenario scenario;
  @override
  State<AiChatScreen> createState() => _AiChatScreenState();
}

class _AiChatScreenState extends State<AiChatScreen> {
  final List<_Msg> msgs = [];
  final ctl = TextEditingController();
  final sc = ScrollController();
  bool busy = false;
  bool autoSpeak = true;
  String? error;
  late final SpeechService _sp;

  @override
  void initState() {
    super.initState();
    _sp = context.read<SpeechService>();
    final s = context.read<AppState>();
    if (s.apiKey.isNotEmpty) {
      WidgetsBinding.instance.addPostFrameCallback((_) => _ask('[start]', hidden: true));
    }
  }

  @override
  void dispose() {
    Future.microtask(_sp.stopSpeaking);
    ctl.dispose();
    sc.dispose();
    super.dispose();
  }

  void _scroll() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (sc.hasClients) sc.animateTo(sc.position.maxScrollExtent, duration: const Duration(milliseconds: 250), curve: Curves.easeOut);
    });
  }

  String _system(AppState s) {
    final l = s.langInfo;
    final n = s.lessonsDone;
    final level = n < 8 ? 'a complete beginner (A1)' : (n < 16 ? 'a beginner (A1 to A2)' : 'an elementary learner (A2)');
    return 'You are a friendly English speaking partner. The learner is $level and their own language is ${l.english} (${l.native}). '
        'Scenario for the role-play: ${widget.scenario.english}. Use very simple, short English. '
        'Reply with ONLY one JSON object and nothing else: {"reply": string, "correction": string, "note": string}. '
        '"reply" is your next line (maximum two short sentences) that continues the role-play and ends with a simple question when natural. '
        '"correction" is the corrected, natural English version of the learner\'s last message if it had mistakes, otherwise an empty string. '
        '"note" is ONE short sentence in ${l.english} explaining the main mistake if correction is not empty, otherwise an empty string. '
        'If the learner message is "[start]", begin the scene yourself with a friendly greeting and a first question.';
  }

  Future<void> _ask(String text, {bool hidden = false}) async {
    final s = context.read<AppState>();
    if (text.trim().isEmpty || busy) return;
    setState(() {
      msgs.add(_Msg(user: true, hidden: hidden, text: text));
      busy = true;
      error = null;
    });
    ctl.clear();
    _scroll();
    try {
      final history = msgs
          .map((m) => {'role': m.user ? 'user' : 'assistant', 'content': m.user ? m.text : (m.raw.isEmpty ? m.text : m.raw)})
          .toList();
      final res = await http
          .post(
            Uri.parse('https://api.anthropic.com/v1/messages'),
            headers: {'content-type': 'application/json', 'x-api-key': s.apiKey, 'anthropic-version': '2023-06-01'},
            body: jsonEncode({'model': s.aiModel, 'max_tokens': 500, 'system': _system(s), 'messages': history}),
          )
          .timeout(const Duration(seconds: 45));
      final body = jsonDecode(utf8.decode(res.bodyBytes)) as Map<String, dynamic>;
      if (res.statusCode != 200) {
        final msg = (body['error'] is Map) ? '${body['error']['message']}' : 'Error';
        throw Exception('${res.statusCode}: $msg');
      }
      final content = body['content'] as List<dynamic>;
      final raw = content.where((c) => c is Map && c['type'] == 'text').map((c) => c['text'].toString()).join('\n');
      var reply = raw;
      var correction = '';
      var note = '';
      final a = raw.indexOf('{');
      final b = raw.lastIndexOf('}');
      if (a >= 0 && b > a) {
        try {
          final j = jsonDecode(raw.substring(a, b + 1)) as Map<String, dynamic>;
          reply = '${j['reply'] ?? ''}';
          correction = '${j['correction'] ?? ''}';
          note = '${j['note'] ?? ''}';
        } catch (_) {}
      }
      if (!mounted) return;
      setState(() {
        if (!hidden) {
          final lastUser = msgs.lastWhere((m) => m.user && !m.hidden, orElse: () => msgs.last);
          lastUser.correction = correction;
          lastUser.note = note;
        }
        msgs.add(_Msg(user: false, text: reply, raw: raw));
      });
      if (!hidden) await s.addXp(2);
      if (autoSpeak) _sp.speak(reply);
    } catch (e) {
      if (mounted) setState(() => error = '$e');
    } finally {
      if (mounted) setState(() => busy = false);
      _scroll();
    }
  }

  Future<void> _mic() async {
    if (_sp.listening) {
      await _sp.stopListening();
      return;
    }
    await _sp.startListening((h) {
      if (h.trim().isNotEmpty && mounted) _ask(h.trim());
    });
  }

  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppState>();
    final sp = context.watch<SpeechService>();
    final noKey = s.apiKey.isEmpty;
    final visible = msgs.where((m) => !m.hidden).toList();
    return Scaffold(
      appBar: AppBar(
        title: Text(s.t(widget.scenario.key)),
        actions: [
          IconButton(
            icon: Icon(autoSpeak ? Icons.volume_up_rounded : Icons.volume_off_rounded),
            onPressed: () => setState(() => autoSpeak = !autoSpeak),
          ),
        ],
      ),
      body: Column(
        children: [
          Expanded(
            child: noKey
                ? Center(
                    child: Padding(
                      padding: const EdgeInsets.all(28),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          const Icon(Icons.key_rounded, size: 48, color: kBrand),
                          const SizedBox(height: 14),
                          Text(s.t('ai_need_key'), textAlign: TextAlign.center, style: const TextStyle(height: 1.5)),
                          const SizedBox(height: 18),
                          FilledButton(onPressed: () => push(context, const AiSettingsScreen()), child: Text(s.t('ai_settings'))),
                        ],
                      ),
                    ),
                  )
                : ListView(
                    controller: sc,
                    padding: const EdgeInsets.fromLTRB(16, 6, 16, 12),
                    children: [
                      for (final m in visible) _bubble(s, m),
                      if (busy)
                        const Padding(
                          padding: EdgeInsets.all(12),
                          child: Align(alignment: Alignment.centerLeft, child: SizedBox(width: 22, height: 22, child: CircularProgressIndicator(strokeWidth: 2.4, color: kBrand))),
                        ),
                      if (error != null)
                        Padding(padding: const EdgeInsets.all(8), child: Text(error!, style: const TextStyle(color: kRed, fontSize: 12.5))),
                    ],
                  ),
          ),
          if (!noKey)
            SafeArea(
              top: false,
              child: Padding(
                padding: const EdgeInsets.fromLTRB(12, 6, 12, 10),
                child: Column(
                  children: [
                    if (sp.listening)
                      Padding(
                        padding: const EdgeInsets.only(bottom: 8),
                        child: Text(sp.heard.isEmpty ? s.t('listening') : '"${sp.heard}"', style: const TextStyle(color: kBrandDark, fontWeight: FontWeight.w500)),
                      ),
                    Row(
                      children: [
                        Expanded(
                          child: TextField(
                            controller: ctl,
                            minLines: 1,
                            maxLines: 3,
                            textInputAction: TextInputAction.send,
                            onSubmitted: (v) => _ask(v.trim()),
                            decoration: InputDecoration(hintText: s.t('ai_hint')),
                          ),
                        ),
                        const SizedBox(width: 8),
                        MicButton(active: sp.listening, onTap: _mic, size: 52, ring: false),
                        const SizedBox(width: 6),
                        IconButton.filled(
                          style: IconButton.styleFrom(backgroundColor: kBrandDark, foregroundColor: Colors.white, minimumSize: const Size(48, 48)),
                          onPressed: busy ? null : () => _ask(ctl.text.trim()),
                          icon: const Icon(Icons.arrow_upward_rounded),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
        ],
      ),
    );
  }

  Widget _bubble(AppState s, _Msg m) {
    if (m.user) {
      return Column(
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          Container(
            margin: const EdgeInsets.only(top: 10, left: 50),
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            decoration: BoxDecoration(color: kBrand, borderRadius: BorderRadius.circular(20)),
            child: Text(m.text, style: const TextStyle(color: Colors.white, fontSize: 15.5)),
          ),
          if (m.correction.trim().isNotEmpty)
            Container(
              margin: const EdgeInsets.only(top: 6, left: 40),
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(color: kMint, borderRadius: BorderRadius.circular(16), border: Border.all(color: kBrand.withAlpha(50))),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(s.t('better_way'), style: const TextStyle(color: kBrandDark, fontSize: 12, fontWeight: FontWeight.w600)),
                  const SizedBox(height: 3),
                  Text(m.correction, style: const TextStyle(fontWeight: FontWeight.w600)),
                  if (m.note.trim().isNotEmpty) ...[
                    const SizedBox(height: 4),
                    NativeText(m.note, s.lang, align: TextAlign.start, style: const TextStyle(color: kMuted, fontSize: 13, height: 1.4)),
                  ],
                ],
              ),
            ),
        ],
      );
    }
    return Align(
      alignment: Alignment.centerLeft,
      child: Container(
        margin: const EdgeInsets.only(top: 10, right: 40),
        padding: const EdgeInsets.fromLTRB(16, 12, 8, 12),
        decoration: BoxDecoration(color: Colors.white, border: Border.all(color: kLine), borderRadius: BorderRadius.circular(20)),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Flexible(child: Text(m.text, style: const TextStyle(fontSize: 15.5, height: 1.4))),
            IconButton(icon: const Icon(Icons.volume_up_rounded, size: 20, color: kBrandDark), onPressed: () => _sp.speak(m.text)),
          ],
        ),
      ),
    );
  }
}

class AiSettingsScreen extends StatefulWidget {
  const AiSettingsScreen({super.key});
  @override
  State<AiSettingsScreen> createState() => _AiSettingsScreenState();
}

class _AiSettingsScreenState extends State<AiSettingsScreen> {
  late final TextEditingController key;
  late final TextEditingController model;
  bool hide = true;

  @override
  void initState() {
    super.initState();
    final s = context.read<AppState>();
    key = TextEditingController(text: s.apiKey);
    model = TextEditingController(text: s.aiModel);
  }

  @override
  Widget build(BuildContext context) {
    final s = context.read<AppState>();
    return Scaffold(
      appBar: AppBar(title: Text(s.t('ai_settings'))),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(18, 6, 18, 28),
        children: [
          Panel(
            color: kMint,
            child: Text('${s.t('ai_note')}\nconsole.anthropic.com', style: const TextStyle(height: 1.5)),
          ),
          const SizedBox(height: 18),
          TextField(
            controller: key,
            obscureText: hide,
            autocorrect: false,
            enableSuggestions: false,
            decoration: InputDecoration(
              labelText: 'API key',
              suffixIcon: IconButton(icon: Icon(hide ? Icons.visibility_outlined : Icons.visibility_off_outlined), onPressed: () => setState(() => hide = !hide)),
            ),
          ),
          const SizedBox(height: 12),
          TextField(controller: model, autocorrect: false, decoration: const InputDecoration(labelText: 'Model')),
          const SizedBox(height: 20),
          FilledButton(
            onPressed: () async {
              await s.saveAi(key.text, model.text);
              if (context.mounted) Navigator.pop(context);
            },
            child: Text(s.t('save')),
          ),
        ],
      ),
    );
  }
}
