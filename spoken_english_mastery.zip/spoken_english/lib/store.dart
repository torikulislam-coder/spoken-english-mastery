import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'data.dart';
import 'l10n.dart';

int epochDay([DateTime? d]) {
  final n = d ?? DateTime.now();
  return DateTime(n.year, n.month, n.day).millisecondsSinceEpoch ~/ 86400000;
}

class AppState extends ChangeNotifier {
  late SharedPreferences prefs;
  late Content content;
  bool ready = false;

  String lang = 'bn';
  String name = '';
  int goalMin = 10;
  bool onboarded = false;

  int xp = 0;
  int streak = 0;
  int bestStreak = 0;
  int lastDay = 0;
  Map<String, int> done = {}; // lessonId -> stars
  Map<String, List<int>> srs = {}; // phraseId -> [box, dueDay]
  Map<String, int> daily = {}; // epochDay -> xp

  Future<void> init() async {
    prefs = await SharedPreferences.getInstance();
    content = await Content.load();
    lang = prefs.getString('lang') ?? 'bn';
    name = prefs.getString('name') ?? '';
    goalMin = prefs.getInt('goal') ?? 10;
    onboarded = prefs.getBool('onboarded') ?? false;
    xp = prefs.getInt('xp') ?? 0;
    streak = prefs.getInt('streak') ?? 0;
    bestStreak = prefs.getInt('best') ?? 0;
    lastDay = prefs.getInt('last') ?? 0;
    try {
      done = (jsonDecode(prefs.getString('done') ?? '{}') as Map).map((k, v) => MapEntry(k as String, v as int));
      srs = (jsonDecode(prefs.getString('srs') ?? '{}') as Map)
          .map((k, v) => MapEntry(k as String, (v as List).map((e) => e as int).toList()));
      daily = (jsonDecode(prefs.getString('daily') ?? '{}') as Map).map((k, v) => MapEntry(k as String, v as int));
    } catch (_) {}
    // streak lapses if more than one day was missed
    if (lastDay != 0 && epochDay() - lastDay > 1) streak = 0;
    ready = true;
    notifyListeners();
  }

  String t(String key, {Map<String, String>? vars}) => tr(key, lang, vars: vars);
  Lang get langInfo => langOf(lang);

  // ---------- onboarding / settings ----------
  Future<void> finishOnboarding(String lg, String nm, int goal) async {
    lang = lg;
    name = nm.trim();
    goalMin = goal;
    onboarded = true;
    await prefs.setString('lang', lang);
    await prefs.setString('name', name);
    await prefs.setInt('goal', goalMin);
    await prefs.setBool('onboarded', true);
    notifyListeners();
  }

  Future<void> setLang(String v) async {
    lang = v;
    await prefs.setString('lang', v);
    notifyListeners();
  }

  Future<void> setName(String v) async {
    name = v.trim();
    await prefs.setString('name', name);
    notifyListeners();
  }

  Future<void> setGoal(int v) async {
    goalMin = v;
    await prefs.setInt('goal', v);
    notifyListeners();
  }

  String get apiKey => prefs.getString('api_key') ?? '';
  String get aiModel => prefs.getString('ai_model') ?? 'claude-sonnet-5-5';
  Future<void> saveAi(String key, String model) async {
    await prefs.setString('api_key', key.trim());
    await prefs.setString('ai_model', model.trim().isEmpty ? 'claude-sonnet-5-5' : model.trim());
    notifyListeners();
  }

  Future<void> resetAll() async {
    xp = 0;
    streak = 0;
    bestStreak = 0;
    lastDay = 0;
    done = {};
    srs = {};
    daily = {};
    await _save();
    notifyListeners();
  }

  // ---------- progress ----------
  int get goalXp => goalMin <= 5 ? 20 : (goalMin <= 10 ? 40 : 80);
  int get todayXp => daily['${epochDay()}'] ?? 0;
  int get lessonsDone => done.length;
  int get phrasesLearned => done.keys.fold(0, (a, id) {
        for (final l in content.lessons) {
          if (l.id == id) return a + l.phrases.length;
        }
        return a;
      });

  bool isDone(Lesson l) => done.containsKey(l.id);
  bool isUnlocked(Lesson l) => l.index == 0 || done.containsKey(content.lessons[l.index - 1].id);
  Lesson? get nextLesson {
    for (final l in content.lessons) {
      if (!done.containsKey(l.id)) return l;
    }
    return null;
  }

  int levelDone(Level lv) => lv.lessons.where((l) => done.containsKey(l.id)).length;

  Future<void> _save() async {
    await prefs.setInt('xp', xp);
    await prefs.setInt('streak', streak);
    await prefs.setInt('best', bestStreak);
    await prefs.setInt('last', lastDay);
    await prefs.setString('done', jsonEncode(done));
    await prefs.setString('srs', jsonEncode(srs));
    await prefs.setString('daily', jsonEncode(daily));
  }

  void _touch() {
    final today = epochDay();
    if (lastDay == today) return;
    streak = (lastDay == today - 1) ? streak + 1 : 1;
    if (streak > bestStreak) bestStreak = streak;
    lastDay = today;
  }

  Future<void> addXp(int n) async {
    xp += n;
    daily['${epochDay()}'] = todayXp + n;
    _touch();
    await _save();
    notifyListeners();
  }

  Future<void> completeLesson(Lesson l, int stars, int earned) async {
    final prev = done[l.id] ?? 0;
    done[l.id] = stars > prev ? stars : prev;
    final today = epochDay();
    for (final p in l.phrases) {
      srs.putIfAbsent(p.id, () => [1, today + 1]);
    }
    await addXp(earned);
  }

  // ---------- spaced repetition (Leitner) ----------
  static const _gaps = [0, 1, 2, 4, 8, 16];

  List<Phrase> dueCards() {
    final today = epochDay();
    final out = <Phrase>[];
    srs.forEach((id, v) {
      if (v[1] <= today && content.phraseById.containsKey(id)) out.add(content.phraseById[id]!);
    });
    return out;
  }

  Future<void> reviewResult(String id, bool good) async {
    final cur = srs[id] ?? [1, epochDay()];
    final box = good ? (cur[0] < 5 ? cur[0] + 1 : 5) : 1;
    srs[id] = [box, epochDay() + _gaps[box]];
    await _save();
    notifyListeners();
  }
}
